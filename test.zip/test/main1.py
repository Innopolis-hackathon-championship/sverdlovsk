import dotenv
import os
from aiogram import Bot, Dispatcher, types
from aiogram.utils import executor
from aiogram.dispatcher.filters.builtin import CommandStart, CommandHelp, Text, IDFilter
from aiogram.dispatcher.filters import Command
from aiogram.types import ReplyKeyboardMarkup, KeyboardButton, ContentType,ReplyKeyboardRemove,InlineKeyboardMarkup,InlineKeyboardButton
from aiogram.contrib.fsm_storage.memory import MemoryStorage
from aiogram.dispatcher.filters.state import StatesGroup, State
from aiogram.dispatcher.storage import FSMContext
from random import *
import sqlite3
from sqlite3 import Error

def create_connection(abc):
    connection = None
    try:
        connection = sqlite3.connect(abc)
        print("Connection to SQLite DB successful")
    except Error as e:
        print(f"The error '{e}' occurred")

    return connection
con=create_connection("Bufet.db")
cur = con.cursor()

dotenv.load_dotenv()
bot = Bot(token="6147585746:AAGePeYju2TmQdzZQPAa0nDR6Djukhle5Ro")
storage = MemoryStorage() #хранит служебную инфу про пользователя
dp = Dispatcher(bot, storage=storage)

on_off_user_name=False

@dp.message_handler(CommandStart()) #/старт
async def bot_start(message: types.Message, state: FSMContext):
    key2 = ReplyKeyboardMarkup(
        keyboard=[
            [
                KeyboardButton(text="Зарегистрироваться"),
                KeyboardButton(text="Войти")
            ]
        ],
        resize_keyboard=True
    )

    on_off_user = False
    await state.update_data(on_off_user=on_off_user)


    await state.update_data(Login=None)

    await state.set_state('Vh_Reg')
    await message.answer(text="Приветствую в буфете", reply_markup=key2)

@dp.message_handler(state="Vh_Reg")
async def bot_Vh_Reg(message: types.Message, state: FSMContext):
    Vh_Reg = message.text
    if Vh_Reg=='Зарегистрироваться':
        await message.answer(text="Придумай логин")
        await state.set_state('Reg')
    elif Vh_Reg=='Войти':
        await message.answer(text="Введи логин")
        await state.set_state('Vh')
    elif Vh_Reg!='' or Vh_Reg != None:
        await message.answer(text="сначала войди или зарегистрируйся")


@dp.message_handler(state="Vh")
async def bot_Vh(message: types.Message, state: FSMContext):
    data = await state.get_data()


    Login = message.text
    if Login != '' or Login != None:
        await state.update_data(Login_Vrem=Login)
        data = await state.get_data()
        cur.execute("SELECT Username FROM Users")
        results_login = cur.fetchall()
        Results_login=[]
        for i in results_login:
            a = i[0]
            Results_login.append(a)
        if Login in Results_login:
            await message.answer(text="Введи пароль")
            await state.set_state('Vh_Pass')
        else:
            await message.answer(text="Логин не найден")
@dp.message_handler(state="Vh_Pass")
async def bot_Vh_Pass(message: types.Message, state: FSMContext):
    data = await state.get_data()

    Pass = message.text
    if Pass != '' or Pass != None:
        cur.execute(f"SELECT Password FROM Users WHERE Username='{data.get('Login_Vrem')}'")
        results_pass = cur.fetchall()

        Results_pass = []
        for i in results_pass:
            a = i[0]
            Results_pass.append(a)
        print(Results_pass)
        if Pass == Results_pass[0]:
            await state.update_data(on_off_user=True)
            Login=data.get('Login_Vrem')
            await state.update_data(Login=Login)
            await state.update_data(Login_Vrem=None)
            data = await state.get_data()
            login=data.get('Login')
            key1 = ReplyKeyboardMarkup(
                keyboard=[
                    [
                        KeyboardButton(text="меню"),
                        KeyboardButton(text="мои заказы"),
                        KeyboardButton(text="баланс")
                    ]
                ],
                resize_keyboard=True
            )
            await message.answer(text=f"Здравствуй,{Login}", reply_markup=key1)
        else:
            await message.answer(text='Пароль или логин не верен')
    await state.reset_state(with_data=False)




@dp.message_handler(state="Reg")
async def bot_Reg(message: types.Message, state: FSMContext):
    data = await state.get_data()

    Login = message.text
    cur.execute("SELECT Username FROM Users")
    results_login = cur.fetchall()
    Results_login = []
    for i in results_login:
        a=i[0]
        Results_login.append(a)
    if not(Login in Results_login):
        await state.update_data(Login_Vrem=Login)
        await message.answer(text="Придумай пароль")
        await state.set_state('Reg_Pass')
    else:
        await message.answer(text="Логин занят,придумай другой")


@dp.message_handler(state="Reg_Pass")
async def bot_Vh_Pass(message: types.Message, state: FSMContext):
    data = await state.get_data()

    Pass = message.text
    if Pass != '' or Pass != None:
        Login=data.get('Login_Vrem')
        await state.update_data(Login=Login)
        await state.update_data(Login_Vrem=None)
        data = await state.get_data()
        login=data.get('Login')
        cur.execute(f"INSERT INTO Users(Username,Password,Balance) VALUES ('{Login}','{Pass}',0)")
        con.commit()

        await message.answer(text=f"Вы зарегистрировались,{login}")

    await state.reset_state(with_data=False)
print("Если ты видишь это сообщение, значит бот в игре")
executor.start_polling(dp)