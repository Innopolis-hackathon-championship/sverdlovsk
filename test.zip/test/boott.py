import dotenv
import os
import random
from aiogram import Bot, Dispatcher, types
from aiogram.utils import executor
from aiogram.dispatcher.filters.builtin import CommandStart, CommandHelp, Text, IDFilter
from aiogram.dispatcher.filters import Command
from aiogram.types import ReplyKeyboardMarkup, KeyboardButton, ContentType
from aiogram.contrib.fsm_storage.memory import MemoryStorage
from aiogram.dispatcher.filters.state import StatesGroup, State
from aiogram.dispatcher.storage import FSMContext
import sqlite3


class Test(StatesGroup):
    Q1 = State()
    Q2 = State()
    Q3 = State()
    Q4 = State()

#клава
button1 = "/ABOUT"
button2 = "/HI"
button3 = "/BYE"
button4 = "/PHOTO"
button5 = "/AUDIO"
button6 = "/CLICKER"
markup5 = ReplyKeyboardMarkup().row(button1, button2, button3).row(button4, button5, button6)

button7 = "ДАЛЕЕ"
button8 = "В МЕНЮ"
rm1 = ReplyKeyboardMarkup().row(button7, button8)

con = sqlite3.connect('db.db')
cursor = con.cursor()
syqaL = "SELECT Anecdot FROM Anecdots"
cursor.execute(syqaL)

syqaL = "SELECT * FROM Users"
cursor.execute(syqaL)
users = cursor.fetchall()

anecdots = cursor.fetchall()
sym = ['+', '-', '/', '*']
temp = True

dotenv.load_dotenv()
bot = Bot(token="6048713152:AAHmLxSJXw2BnXNRzL5jewnovFMzYpnWvZ8")
storage = MemoryStorage()
dp = Dispatcher(bot, storage=storage)

@dp.message_handler(CommandStart())
async def bot_start(message: types.Message):
    await message.answer(text=f"Ну че, погнали народ", reply_markup=markup5)

@dp.message_handler(Command("ABOUT"))
async def bot_about(message: types.Message):
    await message.answer(text=f"Меня создал Лебедев. Да.")

@dp.message_handler(Command("HI"))
async def bot_hi(message: types.Message, state: FSMContext):
    data = await state.get_data()
    if data.get("answer1") == None:
        await message.answer(text=f"Как тебя зовут?")
        await Test.Q1.set()
    else:
        answer = data.get("answer1")
        await message.answer(text=f"Привет, {answer}")


@dp.message_handler(state=Test.Q1)

async def answer_q1(message: types.Message, state: FSMContext):
    answer = message.text
    await state.update_data(answer1=answer)
    await message.answer(text=f"Привет, {answer}")
    await state.reset_state(with_data=False)
#Прощание
@dp.message_handler(Command("BYE"))
async def bot_bye(message: types.Message, state: FSMContext):
    data = await state.get_data()
    if data.get("answer1") == None:
        await message.answer(text=f"Досвиданя")
    else:
        await message.answer(text=f"Досвиданя, {data.get('answer1')}")
#Отправка фото
@dp.message_handler(Command("PHOTO"))
async def bot_photo(message: types.Message):
    photo = []
    photo.append(open("123/test0.png", 'rb'))
    photo.append(open("123/test1.png", 'rb'))
    photo.append(open("123/test2.png", 'rb'))
    await bot.send_photo(chat_id=message.chat.id, photo=photo[random.randint(0, 2)])

#Отправка аудио
@dp.message_handler(Command("AUDIO"))
async def bot_audio(message: types.Message):
    audio = []
    audio.append(open("123/tigr.mp3", 'rb'))
    audio.append(open("123/koshka.mp3", 'rb'))
    audio.append(open("123/slon.mp3", 'rb'))
    await bot.send_audio(chat_id=message.chat.id, audio=audio[random.randint(0, 2)])

#Кликер
@dp.message_handler(Command("CLICKER"))
async def bot_click(message: types.Message, state: FSMContext):
    data = await state.get_data()
    if data.get("clicks") == None:
        clicks = 0
    else:
        clicks = data.get("clicks")
    clicks+=1
    await state.update_data(clicks=clicks)
    await message.answer(text=f"У вас уже {clicks} кликов!")

#Увеличение на кол-во кликов
@dp.message_handler(Command("ADD_CLICK"))
async def bot_add_click(message: types.Message, state: FSMContext):
    await message.answer(text=f"На сколько кликов увеличить?")
    await Test.Q2.set()


@dp.message_handler(state=Test.Q2)
async def answer_q2(message: types.Message, state: FSMContext):
    data = await state.get_data()
    if data.get("clicks") == None:
        clicks = 0
    else:
        clicks = data.get("clicks")
    clicks += int(message.text)
    await state.update_data(clicks=clicks)
    await message.answer(text=f"У вас уже {clicks} кликов!")
    await state.reset_state(with_data=False)

#Сброс кликов
@dp.message_handler(Command("RESET_CLICK"))
async def bot_reset_click(message: types.Message, state: FSMContext):
    clicks = 0
    await state.update_data(clicks=clicks)
    await message.answer(text=f"У вас теперь {clicks} кликов..")


@dp.message_handler(Command("ANECDOT"))
async def bot_anecdot(message: types.Message, state: FSMContext):
    anecdot = [i for i in range(0, len(anecdots))]
    r = random.choice(anecdot)
    anecdot.remove(r)
    print(anecdots)
    await state.update_data(anecdot=anecdot)
    await message.answer(text=f"{anecdots[r][0]}", reply_markup = rm1)
    await Test.Q3.set()


@dp.message_handler(state=Test.Q3)
async def answer_q3(message: types.Message, state: FSMContext):
    if message.text == "ДАЛЕЕ":
        data = await state.get_data()
        anecdot = data.get("anecdot")
        if anecdot != []:
            r = random.choice(anecdot)
            anecdot.remove(r)
            await state.update_data(anecdot=anecdot)
            await message.answer(text=f"{anecdots[r][0]}", reply_markup=rm1)
        else:
            await message.answer(text=f"Короче, кончились анекдоты, ливай.")
    elif message.text == "В МЕНЮ":
        await state.reset_state(with_data=False)
    else:
        await message.answer(text=f"Пользователь дундук, используй имеющиеся команды.")

@dp.message_handler(Command("PLAY_GAME"))
async def bot_play_game(message: types.Message, state: FSMContext):
    global users, temp, con, cursor
    for i in range (0, len(users)):
        print(i)
        if str(message.from_user.id) == str(users[i][1]):
            await state.update_data(user_id = i)
            await state.update_data(record = users[i][2])
            temp = False
    if temp:
        await state.update_data(record=0)
        syqaL = "INSERT INTO Users values (NULL, '{}', '0')".format(str(message.from_user.id))
        print(syqaL)
        cursor.execute(syqaL)
        con.commit()
        temp = True
        syqaL = "SELECT Name FROM Users"
        cursor.execute(syqaL)
        users = cursor.fetchall()
    score = 0
    a = str(random.randint(-999, 999))
    b = str(random.randint(-999, 999))
    c = random.choice(sym)
    e = a+c+b
    print(e)
    d = eval(e)
    nums = [e, d]
    await state.update_data(nums = nums)
    await state.update_data(score = score)
    await message.answer(text=f"{e} = ?")
    await Test.Q4.set()


@dp.message_handler(state=Test.Q4)
async def answer_q4(message: types.Message, state: FSMContext):
    global con, cursor
    data = await state.get_data()
    score = data.get("score")
    if message.text == str(data.get("nums")[1]):
        await message.answer(text=f"Правильно")
        score += 1
        a = str(random.randint(-999, 999))
        b = str(random.randint(-999, 999))
        c = random.choice(sym)
        e = a+c+b
        d = eval(e)
        nums = [e, d]
        await state.update_data(nums=nums)
        await state.update_data(score=score)
        await message.answer(text=f"{e} = ?")
    elif message.text == "СТОП":
        record = data.get("record")
        print(score)
        print(record)
        if score > record:
            syqaL = "UPDATE Users SET Record = {} WHERE ID = {}".format(int(score), int(data.get("user_id")+1))
            print(syqaL)
            cursor.execute(syqaL)
            con.commit()
        await message.answer(text=f"Ваш счёт: {score}")
        await state.reset_state(with_data=False)
    else:
        e = data.get("nums")[0]
        await message.answer(text=f"Неправильно.")
        await message.answer(text=f"{e} = ?")

@dp.message_handler(Command("RECORD"))
async def bot_record(message: types.Message, state: FSMContext):
    global cursor, con
    syqaL = "SELECT * FROM Users ORDER BY Record DESC"
    cursor.execute(syqaL)
    recmans = cursor.fetchall()
    txt = "Таблица рекордов: "+'\n'+str(recmans[0][1])+" - "+str(recmans[0][2])
    print(txt)
    await message.answer(text=f"{txt}")

#Эхо бот
@dp.message_handler(state = None)
async def bot_mes(msg: types.Message):
    await bot.send_message(msg.from_user.id, msg.text)



executor.start_polling(dp)

'''ЭХО-БОТ
 Команда ABOUT – ответ на нее, кто создал бота
 Команда HI – в ответ на нее бот спрашивает имя, следующим сообщением
запоминает его и приветствует пользователя по имени
 Команда BYE – в ответ на эту команду, если бот знает имя, прощается по
имени. Иначе говорит "Досвидания".
 Команда PHOTO – бот высылает фотографию.
 Измените предыдущую команду, пусть бот выбирает СЛУЧАЙНУЮ
фотографию из папки и отправляет ее пользователю.
 Спорно: AUDIO – отправляет случайную песню из папки. (Ограничение
размера?)
 Клавиатура на все существующие команды.
 Команда CLICKER – запоминает сколько раз нажали кнопку и выводит ответ
 Команда ADD_CLICK – спрашивает сколько добавить кликов и после
выводит увеличенное на это сообщение количество кликов
 Команда RESET_CLICK – сбрасывает счетчик
'''