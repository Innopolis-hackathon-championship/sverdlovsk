import dotenv
import os
import random
from aiogram import Bot, Dispatcher, types
from aiogram.utils import executor
from aiogram.dispatcher.filters.builtin import CommandStart, CommandHelp, Text, IDFilter
from aiogram.dispatcher.filters import Command
from aiogram.types import ReplyKeyboardMarkup, KeyboardButton, ContentType
from aiogram.contrib.fsm_storage.memory import MemoryStorage
from aiogram.dispatcher.filters.state import StatesGroup, State
from aiogram.dispatcher.storage import FSMContext
import sqlite3
#await state.update_data(answer1=answer) записать  data = await state.get_data() надо   data.get("clicks")

class Card(StatesGroup):
    Card_number_st = State()
    Card_second_st = State()
    Card_cvc_st = State()


def cardcheck(card_num):
    checksum = 0
    cardnumbers = list(map(int, card_num))
    for count, num in enumerate(cardnumbers):
        if count % 2 == 0:
            buffer = num * 2
            if buffer > 9:
                buffer -= 9
            checksum += buffer
        else:
            checksum += num
    return checksum % 10 == 0


dotenv.load_dotenv()
bot = Bot(token="6203614309:AAHu0WjDVibyUXYseeG-WHZpgyRZvoM8mVg")
storage = MemoryStorage()
dp = Dispatcher(bot, storage=storage)

@dp.message_handler(CommandStart())
async def bot_start(message: types.Message):
    await message.answer(text=f"Ну че, погнали народ")

@dp.message_handler(Command("Add_card"))
async def add_start(message: types.Message, state: FSMContext):
    await bot.send_message(chat_id= message.chat.id, text= "Ведите номер карты(без пробелов)")
    await Card.Card_number_st.set()



@dp.message_handler(state = Card.Card_number_st)
async def add_start(message: types.Message,  state: FSMContext):
    card_num = message.text
    if card_num.isnumeric() and cardcheck(card_num) == True:
        await bot.send_message(chat_id=message.chat.id, text = "Записан, введите мм/гг без слэша")
        await state.update_data(card_num=card_num)
        await Card.Card_second_st.set()
    else:
        await bot.send_message(chat_id=message.chat.id, text="Ваша карта не валидна, попробуйте ещё раз.")

@dp.message_handler(state = Card.Card_second_st)
async def add_start(message: types.Message,  state: FSMContext):

    card_g = message.text
    if card_g.isnumeric():
        await bot.send_message(chat_id=message.chat.id, text = "Записан, напишите cvc")
        await state.update_data(card_g=card_g)
        await Card.Card_cvc_st.set()
    else:
        await bot.send_message(chat_id=message.chat.id, text="Еще раз")

@dp.message_handler(state = Card.Card_cvc_st)
async def add_start(message: types.Message,  state: FSMContext):

    card_cvc = message.text
    if card_cvc.isnumeric():

        await state.update_data(card_cvc=card_cvc)
        data = await state.get_data()
        data_1 = data.get("card_num")

        data_2 = await state.get_data()
        data_3 = data_2.get("card_g")



        await bot.send_message(chat_id=message.chat.id, text = "Готово")
        await bot.send_message(chat_id=message.chat.id, text=f"Номер карты: {data_1}")
        await bot.send_message(chat_id=message.chat.id, text=f"мм/гг : {data_3}")
        await bot.send_message(chat_id=message.chat.id, text=f"cvc код : {card_cvc}")

        await state.reset_state(with_data=False)
    else:
        await bot.send_message(chat_id=message.chat.id, text="Еще раз")




@dp.message_handler(Command("See_card"))
async def add_start(message: types.Message, state: FSMContext):
    data = await state.get_data()
    data_1 = data.get("card_num")

    data_2 = await state.get_data()
    data_3 = data_2.get("card_g")

    data_4 = await state.get_data()
    data_5 = data_4.get("card_cvc")

    await bot.send_message(chat_id=message.chat.id, text=f"Номер карты: {data_1}")
    await bot.send_message(chat_id=message.chat.id, text=f"мм/гг : {data_3}")
    await bot.send_message(chat_id=message.chat.id, text=f"cvc код : {data_5}")












executor.start_polling(dp)






