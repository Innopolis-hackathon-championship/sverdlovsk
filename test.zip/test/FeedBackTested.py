@dp.message_handler(Command("feedback")) #/старт
async def bot_feedback(message: types.Message,state: FSMContext):
    await message.answer(text="Пожалуйста,оцените нас по 5-бальной шкале!")
    await state.set_state("StarRate")


@dp.message_handler(state="StarRate")
async def bot_starrate(message: types.Message,state: FSMContext):
    if int(message.text) <=5:
        Stars = message.text
        await state.update_data(StarRate = Stars)
        await message.answer(text="Спасибо за вашу оценку!Не хотели бы вы поделиться с нами вашими впечатлениями и оставть отзыв?")
        await state.set_state("ChoosingOptFeedBack")
    else:
        await message.answer(
            text="Ты че попутал?")
        await state.set_state("StarRate")

@dp.message_handler(state="ChoosingOptFeedBack")
async def bot_choosing(message: types.Message,state: FSMContext):
    data = await state.get_data()
    Answer = message.text
    if Answer == "Да":
        await message.answer(text="Пожалуйста,опишите всё,что вам понравилось как можно подробнее!")
        await state.set_state("FeedBack")
    elif Answer == "Нет":
        rate = data.get('StarRate')
        username = data.get('Username')
        connect = sqlite3.connect("Bufet (2).db")
        cursor = connect.cursor()
        cursor.execute(f"INSERT INTO FeedBack(Username,Rate) VALUES('{username}',{rate})")
        connect.commit()
        connect.close()
        await message.answer(text="Возвращайтесь к нам ещё!")
        await state.reset_state(with_data=False)
    else:
        await message.answer(text="Чета я не понял!")
        await state.set_state("ChoosingOptFeedBack")

@dp.message_handler(state="FeedBack")
async def bot_feedback_check(message: types.Message,state: FSMContext):
    data = await state.get_data()
    FeedBack = message.text
    username = data.get('Username')
    rate = data.get('StarRate')
    connect = sqlite3.connect("Bufet (2).db")
    cursor = connect.cursor()
    cursor.execute(f"INSERT INTO FeedBack(Username,User_Feedback,Rate) VALUES('{username}','{FeedBack}',{rate})")
    connect.commit()
    connect.close()
    await message.answer(text="Большое спасибо за отзыв,ждем вас снова!")
    await state.reset_state(with_data=False)


executor.start_polling(dp)