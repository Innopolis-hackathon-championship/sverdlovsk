import dotenv
import os
import random
from aiogram import Bot, Dispatcher, types
from aiogram.utils import executor
from aiogram.dispatcher.filters.builtin import CommandStart, CommandHelp, Text, IDFilter
from aiogram.dispatcher.filters import Command
from aiogram.types import ReplyKeyboardMarkup, KeyboardButton, ContentType, InlineKeyboardButton,InlineKeyboardMarkup
from aiogram.contrib.fsm_storage.memory import MemoryStorage
from aiogram.dispatcher.filters.state import StatesGroup, State
from aiogram.dispatcher.storage import FSMContext
import sqlite3

con = sqlite3.connect('Bufet.db')
cursor = con.cursor()
syqaL = "SELECT * FROM Menu"
cursor.execute(syqaL)

markup1 = ReplyKeyboardMarkup(resize_keyboard=True).row("Войти", "Зарегистрироваться")
menuha = cursor.fetchall()
markup2 = ReplyKeyboardMarkup(resize_keyboard=True)
print(menuha)
for i in menuha:
    if i[3] == 0:
        pass
    else:
        markup2.add(str(i[0])+'. '+str(i[1]+' ('+str(i[2])+' руб.)'))
markup2.add("Это всё")

markup3 = ReplyKeyboardMarkup(resize_keyboard=True).row("Это всё", "Выбрать ещё позиции")

markup4 = ReplyKeyboardMarkup(resize_keyboard=True).row("Сделать заказ", "Текущие заказы", "Пополнить баланс")

inline_btn_3 = InlineKeyboardButton("Завершить", callback_data='button3')
inline_kb1 = InlineKeyboardMarkup().add(inline_btn_3)

button1 = "/ABOUT"
button2 = "/HI"
button3 = "/BYE"
button4 = "/PHOTO"
button5 = "/AUDIO"
button6 = "/CLICKER"
markup5 = ReplyKeyboardMarkup().row(button1, button2, button3).row(button4, button5, button6)


syqaL = "SELECT * FROM Users"
cursor.execute(syqaL)
users = cursor.fetchall()

dotenv.load_dotenv()
bot = Bot(token="6048713152:AAHmLxSJXw2BnXNRzL5jewnovFMzYpnWvZ8")
storage = MemoryStorage()
dp = Dispatcher(bot, storage=storage)

class Zakaz(StatesGroup):
    vetv = State ()
    shopping = State()
    amount_check = State()
    otv = State()
    zaka = State()
    form = State()
    adres = State()
    zaka_kod = State()

@dp.message_handler(Command("start"))
async def bot_reset_click(message: types.Message, state: FSMContext):
    await message.answer(text=f"Привет! Я бот по доставке товаров из булочной. У меня ты можешь заказать любой товар без толкучки в очередях. Чтобы вызвать меню, отправь команду /menu в чат. Прежде чем пользоваться ботом, создай или войди в аккаунт.", reply_markup=markup1)

    on_off_user = False
    await state.update_data(on_off_user=on_off_user)

    await state.update_data(Login = None)
    await state.update_data(Login_ID = 0)
    await state.set_state('Vh_Reg')

@dp.message_handler(state="Vh_Reg")
async def bot_Vh_Reg(message: types.Message, state: FSMContext):
    Vh_Reg = message.text
    if Vh_Reg=='Зарегистрироваться':
        await message.answer(text="Придумай логин.")
        await state.set_state('Reg')
    elif Vh_Reg=='Войти':
        await message.answer(text="Введи логин.")
        await state.set_state('Vh')
    elif Vh_Reg!='' or Vh_Reg != None:
        await message.answer(text="Cначала войди или зарегистрируйся.")


@dp.message_handler(state="Vh")
async def bot_Vh(message: types.Message, state: FSMContext):
    Login = message.text
    if Login != '' or Login != None:
        await state.update_data(Login_Vrem=Login)
        cursor.execute("SELECT Username FROM Users")
        results_login = cursor.fetchall()
        Results_login=[]
        for i in results_login:
            a = i[0]
            Results_login.append(a)
        if Login in Results_login:
            await message.answer(text="Введи пароль.")
            await state.set_state('Vh_Pass')
        else:
            await message.answer(text="Логин не найден.")

@dp.message_handler(state="Vh_Pass")
async def bot_Vh_Pass(message: types.Message, state: FSMContext):
    data = await state.get_data()
    Pass = message.text
    if Pass != '' or Pass != None:
        cursor.execute(f"SELECT Password FROM Users WHERE Username='{data.get('Login_Vrem')}'")
        results_pass = cursor.fetchall()
        Results_pass = []
        for i in results_pass:
            a = i[0]
            Results_pass.append(a)
        print(Results_pass)
        if Pass == Results_pass[0]:
            await state.update_data(on_off_user = True)
            Login = data.get('Login_Vrem')
            await state.update_data(Login = Login)
            await state.update_data(Login_Vrem = None)
            await message.answer(text=f"Здравствуй, {Login}!", reply_markup=markup4)
            syqaL = f"SELECT ID FROM Users WHERE Username = '{Login}'"
            cursor.execute(syqaL)
            orders = cursor.fetchall()
            await state.update_data(Login_ID=orders[0][0])
            await Zakaz.vetv.set()
        else:
            await message.answer(text='Пароль или логин не верен.')

@dp.message_handler(state="Reg")
async def bot_Reg(message: types.Message, state: FSMContext):
    Login = message.text
    cursor.execute("SELECT Username FROM Users")
    results_login = cursor.fetchall()
    Results_login = []
    for i in results_login:
        a=i[0]
        Results_login.append(a)
    if not(Login in Results_login):
        await state.update_data(Login_Vrem=Login)
        await message.answer(text="Придумай пароль.")
        await state.set_state('Reg_Pass')
    else:
        await message.answer(text="Логин занят,придумай другой.")


@dp.message_handler(state="Reg_Pass")
async def bot_Vh_Pass(message: types.Message, state: FSMContext):
    data = await state.get_data()

    Pass = message.text
    if Pass != '' or Pass != None:
        Login=data.get('Login_Vrem')
        await state.update_data(Login=Login)
        await state.update_data(Login_Vrem=None)
        data = await state.get_data()
        login=data.get('Login')
        cursor.execute(f"INSERT INTO Users(Username,Password,Balance, Status) VALUES ('{Login}','{Pass}', 0, 0)")
        con.commit()

        await message.answer(text=f"Вы зарегистрировались,{login}", reply_markup= markup4)
        syqaL = f"SELECT ID FROM Users WHERE Username = '{login}'"
        cursor.execute(syqaL)
        orders = cursor.fetchall()
        await state.update_data(Login_ID=orders[0][0])
        await Zakaz.vetv.set()
#----
@dp.message_handler(Command("feedback")) #/старт
async def bot_feedback(message: types.Message,state: FSMContext):
    await message.answer(text="Пожалуйста, оцените нас по 5-бальной шaкале!")
    await state.set_state("StarRate")


@dp.message_handler(state="StarRate")
async def bot_starrate(message: types.Message,state: FSMContext):
    if int(message.text) <=5:
        Stars = message.text
        await state.update_data(StarRate = Stars)
        await message.answer(text="Спасибо за вашу оценку! Не хотели бы вы поделиться с нами вашими впечатлениями и оставть отзыв?")
        await state.set_state("ChoosingOptFeedBack")
    else:
        await message.answer(text="Ты че попутал?")
        await state.set_state("StarRate")

@dp.message_handler(state="ChoosingOptFeedBack")
async def bot_choosing(message: types.Message,state: FSMContext):
    data = await state.get_data()
    if message.text == "Да":
        await message.answer(text="Пожалуйста,опишите всё,что вам понравилось как можно подробнее!")
        await state.set_state("FeedBack")
    elif message.text == "Нет":
        rate = data.get('StarRate')
        username = data.get('Username')
        connect = sqlite3.connect("Bufet.db")
        cursor = connect.cursor()
        cursor.execute(f"INSERT INTO FeedBack(Username,Rate) VALUES('{username}',{rate})")
        connect.commit()
        connect.close()
        await message.answer(text="Возвращайтесь к нам ещё!")
        await state.reset_state(with_data=False)
    else:
        await message.answer(text="Чета я не понял!")
        await state.set_state("ChoosingOptFeedBack")

@dp.message_handler(state="FeedBack")
async def bot_feedback_check(message: types.Message,state: FSMContext):
    data = await state.get_data()
    FeedBack = message.text
    username = data.get('Username')
    rate = data.get('StarRate')
    connect = sqlite3.connect("Bufet.db")
    cursor = connect.cursor()
    cursor.execute(f"INSERT INTO FeedBack(Username,User_Feedback,Rate) VALUES('{username}','{FeedBack}',{rate})")
    connect.commit()
    connect.close()
    await message.answer(text="Большое спасибо за отзыв,ждем вас снова!")
    await state.reset_state(with_data=False)
#-----
@dp.message_handler(state=Zakaz.vetv)
async def bot_reset_click(message: types.Message, state: FSMContext):
    data = await state.get_data()
    if message.text == "Сделать заказ":
        await message.answer(text=f"Вот моё меню: ", reply_markup=markup2)
        await Zakaz.shopping.set()
    elif message.text == "Текущие заказы":
        syqaL = f"SELECT * FROM Orders WHERE Username = '{data.get('Login')}'"
        print(syqaL)
        cursor.execute(syqaL)
        orders = cursor.fetchall()
        print(orders)
        await message.answer(text=f"Вот твои заказы:")
        for i in orders:
            tx = "Заказ: " + i[2]
            if i[3] == 0: tx += "В СБОРКЕ"
            elif i[3] == 0: tx += "У КУРЬЕРА"
            elif i[3] == 0: tx += "ДОСТАВЛЕН"
            tx += "\n КОД ПОЛУЧЕНИЯ: " + i[5]
            await message.answer(text=tx)
    elif message.text == "Взять заказ":
        if users[data.get('Login_ID')-1][4] == 1:
            syqaL = "SELECT * FROM Orders WHERE Status = 0"
            print(syqaL)
            cursor.execute(syqaL)
            orders = cursor.fetchall()
            tx = "НОМЕР ЗАКАЗА: " + str(orders[0][0]) + "\n КАБИНЕТ ДЛЯ ДОСТАВКИ: " + orders[0][4]
            print(orders[0][0]+1)
            syqaL = "UPDATE Orders SET Status = 1 WHERE ID = {}".format(orders[0][0]+1)
            cursor.execute(syqaL)
            con.commit()
            await message.answer(text=tx)
        else:
            await message.answer(text="Недостаточно полномочий.")
    elif message.text == "Сдать заказ":
        if users[data.get('Login_ID')-1][4] == 1:
            await message.answer(text="Введите номер заказа, который вы хотите сдать.")
            await Zakaz.zaka.set()
        else:
            await message.answer(text="Недостаточно полномочий.")

@dp.message_handler(state=Zakaz.zaka)
async def answer_q2(message: types.Message, state: FSMContext):
    await state.update_data(zakaz = message.text)
    await message.answer(text="Введите приватный код заказа.")
    await Zakaz.zaka_kod.set()

@dp.message_handler(state=Zakaz.zaka_kod)
async def answer_q2(message: types.Message, state: FSMContext):
    data = await state.get_data()
    syqaL = f"SELECT Private_code FROM Orders WHERE ID = {data.get('zakaz')}"
    cursor.execute(syqaL)
    orders = cursor.fetchall()
    await message.answer(text="Введите приватный код заказа.")
    if message.text == orders[0][0]:
        syqaL = f"UPDATE Orders SET Status = 2 WHERE ID = {data.get('zakaz')}"
        cursor.execute(syqaL)
        con.commit()
        await message.answer(text="Заказ сдан")
        syqaL = f"SELECT Username FROM Orders WHERE ID = {data.get('zakaz')}"
        print(syqaL)
        cursor.execute(syqaL)
        orders = cursor.fetchall()
        await bot.send_message(message.from_user.id, f"Заказ {data.get('zakaz')} доставлен.", reply_markup=inline_kb1)
    else:
        await message.answer(text="Неверный приватный код")
    await Zakaz.zaka_kod.set()

@dp.callback_query_handler(text='button3')
async def process_callback_minus(callback_query: types.CallbackQuery, state: FSMContext):
    await bot.answer_callback_query(callback_query.id)
    await bot.edit_message_reply_markup(
        chat_id=callback_query.from_user.id,
        message_id=callback_query.message.message_id,
        reply_markup=None
    )
    await bot.send_message(callback_query.from_user.id, "Пожалуйста, оцените нас по 5-бальной шaкале, сэр!")
    await state.set_state("StarRate")

@dp.message_handler(state=Zakaz.shopping)
async def answer_q2(message: types.Message, state: FSMContext):
    global menuha
    data = await state.get_data()
    t = ""
    for i in range (0, len(message.text)):
        if message.text[i] != ".":
            t += message.text[i]
        else:
            break
    te = int(t) - 1
    await message.answer(text=f"Мммм, {menuha[te][1]}, отличный выбор! У нас их есть {menuha[te][3]} штук, сколько тебе нужно?", reply_markup=markup2)
    if data.get("food_id") != None:
        print(data.get("food_id"))
        a = data.get("food_id")
        a.append(te)
        await state.update_data(food_id=a)
    else:
        await state.update_data(food_id=[te])
    data = await state.get_data()
    print(data.get("food_id"))
    await Zakaz.amount_check.set()

@dp.message_handler(state=Zakaz.amount_check)
async def answer_q2(message: types.Message, state: FSMContext):
    global menuha
    data = await state.get_data()
    print(1)
    print(data.get("food_id"))
    if int(message.text) > menuha[len(data.get("food_id"))][3]:
        await message.answer("Это слишком много, у нас столько нет. Возьми поменьше, пожалуйста.")
        await Zakaz.amount_check.set()
    else:
        if data.get("food_amount") != None:
            a = data.get("food_amount")
            a.append(int(message.text))
            await state.update_data(food_amount=a)
        else:
            await state.update_data(food_amount=[int(message.text)])
        data = await state.get_data()
        text = ""
        for i in range (0, len(data.get("food_id"))):
            text += menuha[data.get("food_id")[i]][1] + " в количестве " + str(data.get("food_amount")[i]) + " штук" + '\n'
        await message.answer(text="Отлично! Вот твой заказ: \n"+text)
        await state.update_data(order = text)
        await message.answer(text=f"Хочешь взять что-нибудь ещё, или это весь заказ?", reply_markup=markup3)
        await Zakaz.otv.set()

@dp.message_handler(state=Zakaz.otv)
async def answer_q2(message: types.Message, state: FSMContext):
    if message.text == "Это всё":
        data = await state.get_data()
        price = 0
        for i in range(0, len(data.get("food_id"))):
            price += menuha[data.get("food_id")[i]][2] * data.get("food_amount")[i]
        print(price)
        if users[int(data.get("Login_ID")-1)][3] - price >= 0:
            syqaL = "UPDATE Users SET Balance = {} WHERE ID = {}".format(int(users[data.get("Login_ID")-1][3] - price), int(data.get("Login_ID")-1)+1)
            cursor.execute(syqaL)
            con.commit()
            await message.answer(text=f"Заказ сформирован! Укажите адрес, на который необходимо доставить.")
            await Zakaz.adres.set()
        else:
            await message.answer(text=f"Недостаточно средств!")
    elif message.text == "Выбрать ещё позиции":
        await message.answer(text=f"Вот моё меню: ", reply_markup=markup2)
        await Zakaz.shopping.set()

@dp.message_handler(state=Zakaz.adres)
async def answer_q2(message: types.Message, state: FSMContext):
    data = await state.get_data()
    a = ""
    for i in range (10): a += str(random.randint(0, 9))
    syqaL = "INSERT INTO Orders values (NULL,'{}', '{}', 0, '{}', '{}')".format(users[data.get("Login_ID")-1][1], data.get("order"), message.text, a)
    print(syqaL)
    cursor.execute(syqaL)
    con.commit()
    await message.answer(text=f"Отлично! Ожидайте доставки.", reply_markup=markup4)
    await Zakaz.vetv.set()


executor.start_polling(dp)