import sqlite3
import dotenv
import os
from aiogram import Bot, Dispatcher, types
from aiogram.utils import executor
from aiogram.dispatcher.filters.builtin import CommandStart, CommandHelp, Text, IDFilter
from aiogram.dispatcher.filters import Command
from aiogram.types import ReplyKeyboardMarkup, KeyboardButton, ContentType,InlineKeyboardButton,InlineKeyboardMarkup
from aiogram.contrib.fsm_storage.memory import MemoryStorage
from aiogram.dispatcher.filters.state import StatesGroup, State
from aiogram.dispatcher.storage import FSMContext
import sqlite3

class Test(StatesGroup):
    Q1 = State()
    Q2 = State()

dotenv.load_dotenv()
bot = Bot(token="6521822586:AAGToz4tfz_9fa8HrOX528tHbDZa3Ub7yyo")
storage = MemoryStorage() #хранит служебную инфу про пользователя
dp = Dispatcher(bot, storage=storage) #диспетчеру нужен бот и сторайдж

inline_btn_1 = InlineKeyboardButton('+', callback_data='button1')
inline_btn_2 = InlineKeyboardButton('-', callback_data='button2')
inline_btn_3 = InlineKeyboardButton("Завершить", callback_data='button3')
inline_kb1 = InlineKeyboardMarkup().add(inline_btn_1,inline_btn_2,inline_btn_3)

#bot.py
@dp.message_handler(CommandStart())
async def process_command_1(message: types.Message, state: FSMContext):
    await message.reply("Первая инлайн кнопка", reply_markup=inline_kb1)
    await state.update_data(Amount = 0)


@dp.callback_query_handler(text='button1')
async def process_callback_plus(callback_query: types.CallbackQuery, state: FSMContext):
    data = await state.get_data()
    Amount = data.get("Amount")
    await bot.answer_callback_query(callback_query.id)
    Amount = Amount + 1
    await bot.send_message(callback_query.from_user.id, f'Ваш счёт:{Amount}')
    await state.update_data(Amount = Amount)

@dp.callback_query_handler(text='button2')
async def process_callback_minus(callback_query: types.CallbackQuery, state: FSMContext):
    data = await state.get_data()
    Amount = data.get("Amount")
    await bot.answer_callback_query(callback_query.id)
    Amount = Amount - 1
    await bot.send_message(callback_query.from_user.id, f'Ваш счёт:{Amount}')
    await state.update_data(Amount=Amount)



@dp.callback_query_handler(text='button3')
async def process_callback_minus(callback_query: types.CallbackQuery, state: FSMContext):
    data = await state.get_data()
    Amount = data.get("Amount")
    await bot.answer_callback_query(callback_query.id)
    await bot.edit_message_reply_markup(
        chat_id=callback_query.from_user.id,
        message_id=callback_query.message.message_id,
        reply_markup=None
    )
    await bot.send_message(callback_query.from_user.id, f'Ваш счёт:{Amount}')
executor.start_polling(dp)