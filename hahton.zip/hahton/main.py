import dotenv
import os
import random
from aiogram import Bot, Dispatcher, types
from aiogram.utils import executor
from aiogram.dispatcher.filters.builtin import CommandStart, CommandHelp, Text, IDFilter
from aiogram.dispatcher.filters import Command
from aiogram.types import ReplyKeyboardMarkup, KeyboardButton, ContentType, InlineKeyboardButton,InlineKeyboardMarkup
from aiogram.contrib.fsm_storage.memory import MemoryStorage
from aiogram.dispatcher.filters.state import StatesGroup, State
from aiogram.dispatcher.storage import FSMContext
import sqlite3
from settings import TG_TOKEN

con = sqlite3.connect('Bufet.db')
cursor = con.cursor()
sql_requests = "SELECT * FROM Menu"
cursor.execute(sql_requests)

markup1 = ReplyKeyboardMarkup(resize_keyboard=True).row("Войти", "Зарегистрироваться")
menuha = cursor.fetchall()
markup2 = ReplyKeyboardMarkup(resize_keyboard=True)
print(menuha)
for i in menuha:
    if i[3] == 0:
        pass
    else:
        markup2.add(str(i[0])+'. '+str(i[1]+' ('+str(i[2])+' руб.)'))
markup2.add("Это всё")

markup3 = ReplyKeyboardMarkup(resize_keyboard=True).row("Это всё", "Выбрать ещё позиции")

markup4 = ReplyKeyboardMarkup(resize_keyboard=True).row("Сделать заказ", "Текущие заказы", "Пополнить баланс")

markup6 = ReplyKeyboardMarkup(resize_keyboard=True).row("Сделать заказ", "Текущие заказы", "Пополнить баланс").row("Взять заказ", "Сдать заказ")

markup7 = ReplyKeyboardMarkup(resize_keyboard=True).row("Оставить отзыв","Не оставлять отзыв")

markup8 = ReplyKeyboardMarkup(resize_keyboard=True).row("Привязать","Отмена")

markup9 = ReplyKeyboardMarkup(resize_keyboard=True).row("Сдать заказ","В меню")

key3 = ReplyKeyboardMarkup(
    keyboard=[
        [
            KeyboardButton(text="Заказы"),
            KeyboardButton(text="Наличие"),
        ]
    ],
    resize_keyboard=True
)

inline_btn_1 = InlineKeyboardButton("Оставить отзыв", callback_data='feedback')
inline_btn_2 = InlineKeyboardButton("Не оставлять отзыв", callback_data='nofeedback')
inline_kb1 = InlineKeyboardMarkup().add(inline_btn_1, inline_btn_2)

button1 = "/ABOUT"
button2 = "/HI"
button3 = "/BYE"
button4 = "/PHOTO"
button5 = "/AUDIO"
button6 = "/CLICKER"
markup5 = ReplyKeyboardMarkup().row(button1, button2, button3).row(button4, button5, button6)


sql_requests = "SELECT * FROM Users"
cursor.execute(sql_requests)
users = cursor.fetchall()

dotenv.load_dotenv()
bot = Bot(token=TG_TOKEN)
storage = MemoryStorage()
dp = Dispatcher(bot, storage=storage)

class Zakaz(StatesGroup):
    vetv = State ()
    shopping = State()
    amount_check = State()
    otv = State()
    zaka = State()
    form = State()
    adres = State()
    zaka_kod = State()
    otz_tav = State()
    givee = State()
    sgive = State()

class Card(StatesGroup):
    Card_number_st = State()
    Card_second_st = State()
    Card_cvc_st = State()
    add_card = State()
    card_add_menu = State()
    add_balance = State()

def cardcheck(card_num):
    checksum = 0
    cardnumbers = list(map(int, card_num))
    for count, num in enumerate(cardnumbers):
        if count % 2 == 0:
            buffer = num * 2
            if buffer > 9:
                buffer -= 9
            checksum += buffer
        else:
            checksum += num
    return checksum % 10 == 0


@dp.message_handler(Command("start"))
async def bot_reset_click(message: types.Message, state: FSMContext):
    await message.answer(text=f"Привет! Я бот по доставке товаров из булочной. У меня ты можешь заказать любой товар без толкучки в очередях. Прежде чем пользоваться ботом, создай или войди в аккаунт.", reply_markup=markup1)
    on_off_user = False
    await state.update_data(on_off_user=on_off_user)

    await state.update_data(Login = None)
    await state.update_data(Login_ID = 0)
    await state.set_state('Vh_Reg')

@dp.message_handler(state="Vh_Reg")
async def bot_Vh_Reg(message: types.Message, state: FSMContext):
    Vh_Reg = message.text
    if Vh_Reg=='Зарегистрироваться':
        await message.answer(text="Придумай логин.", reply_markup=types.ReplyKeyboardRemove())
        await state.set_state('Reg')
    elif Vh_Reg=='Войти':
        await message.answer(text="Введи логин.", reply_markup=types.ReplyKeyboardRemove())
        await state.set_state('Vh')
    elif Vh_Reg!='' or Vh_Reg != None:
        await message.answer(text="Cначала войди или зарегистрируйся.")


@dp.message_handler(state="Vh")
async def bot_Vh(message: types.Message, state: FSMContext):
    Login = message.text
    if Login != '' or Login != None:
        await state.update_data(Login_Vrem=Login)
        cursor.execute("SELECT Username FROM Users")
        results_login = cursor.fetchall()
        Results_login=[]
        for i in results_login:
            a = i[0]
            Results_login.append(a)
        if Login in Results_login:
            await message.answer(text="Введи пароль.")
            await state.set_state('Vh_Pass')
        else:
            await message.answer(text="Логин не найден.")

@dp.message_handler(state="Vh_Pass")
async def bot_Vh_Pass(message: types.Message, state: FSMContext):
    data = await state.get_data()
    Pass = message.text
    if Pass != '' or Pass != None:
        cursor.execute(f"SELECT Password FROM Users WHERE Username='{data.get('Login_Vrem')}'")
        results_pass = cursor.fetchall()
        Results_pass = []
        for i in results_pass:
            a = i[0]
            Results_pass.append(a)
        print(Results_pass)
        if Pass == Results_pass[0]:
            await state.update_data(on_off_user = True)
            Login = data.get('Login_Vrem')
            await state.update_data(Login = Login)
            await state.update_data(Login_Vrem = None)
            syqaL = f"SELECT ID FROM Users WHERE Username = '{Login}'"
            cursor.execute(syqaL)
            orders = cursor.fetchall()
            await state.update_data(Login_ID=orders[0][0])
            syqaL = f"SELECT Status FROM Users WHERE ID = '{orders[0][0]}'"
            cursor.execute(syqaL)
            orders = cursor.fetchall()
            await state.update_data(Role=orders[0][0])
            data = await state.get_data()
            if users[data.get('Login_ID') - 1][4] == 1:
                await message.answer(text=f"Здравствуй, {Login}!", reply_markup=markup6)
            elif orders[0][0]:
                await message.answer(text=f"Здравствуй, {Login}!", reply_markup=key3)
            else:
                await message.answer(text=f"Здравствуй, {Login}!", reply_markup=markup4)
            await Zakaz.vetv.set()
        else:
            await message.answer(text='Пароль или логин не верен.')

@dp.message_handler(state="Reg")
async def bot_Reg(message: types.Message, state: FSMContext):
    Login = message.text
    cursor.execute("SELECT Username FROM Users")
    results_login = cursor.fetchall()
    Results_login = []
    for i in results_login:
        a=i[0]
        Results_login.append(a)
    if not(Login in Results_login):
        await state.update_data(Login_Vrem=Login)
        await message.answer(text="Придумай пароль.")
        await state.set_state('Reg_Pass')
    else:
        await message.answer(text="Логин занят,придумай другой.")


@dp.message_handler(state="Reg_Pass")
async def bot_Vh_Pass(message: types.Message, state: FSMContext):
    data = await state.get_data()

    Pass = message.text
    if Pass != '' or Pass != None:
        Login=data.get('Login_Vrem')
        await state.update_data(Login=Login)
        await state.update_data(Login_Vrem=None)
        data = await state.get_data()
        login=data.get('Login')
        cursor.execute(f"INSERT INTO Users(Username,Password,Balance, Status) VALUES ('{Login}','{Pass}', 0, 0)")
        con.commit()
        if users[data.get('Login_ID') - 1][4] == 1:
            await message.answer(text=f"Вы зарегистрировались,{login}", reply_markup=markup6)
        else:
            await message.answer(text=f"Вы зарегистрировались,{login}", reply_markup=markup4)
        sql_requests = f"SELECT ID FROM Users WHERE Username = '{login}'"
        cursor.execute(sql_requests)
        orders = cursor.fetchall()
        await state.update_data(Login_ID=orders[0][0])
        cursor.execute(sql_requests)
        orders = cursor.fetchall()
        await state.update_data(Role=orders[0][0])
        await Zakaz.vetv.set()

@dp.message_handler(state=Card.add_balance)
async def answer_q2(message: types.Message, state: FSMContext):
    if message.text.isnumeric():
        data = await state.get_data()
        print(data.get('Login_ID'))
        sql_requests = f"SELECT Balance FROM Users WHERE ID = '{data.get('Login_ID')}'"
        cursor.execute(sql_requests)
        a = cursor.fetchall()
        print(a)
        sql_requests = f"UPDATE Users SET Balance = {a[0][0] + int(message.text)} WHERE ID = {data.get('Login_ID')}"
        cursor.execute(sql_requests)
        con.commit()
        if users[data.get('Login_ID') - 1][4] == 1:
            await message.answer(text=f"Баланс пополнен.", reply_markup=markup6)
        else:
            await message.answer(text=f"Баланс пополнен.", reply_markup=markup4)
        await Zakaz.vetv.set()
    else:
        await message.answer(text='Введи реальную сумму, пожалуйста.')


@dp.message_handler(state = Card.add_card)
async def add_start(message: types.Message, state: FSMContext):
    if message.text == "Привязать":
        await bot.send_message(chat_id= message.chat.id, text= "Ведите номер карты (без пробелов).")
        await Card.Card_number_st.set()
    elif message.text == "Отмена":
        await Zakaz.vetv.set()

@dp.message_handler(state = Card.Card_number_st)
async def add_start(message: types.Message,  state: FSMContext):
    card_num = message.text
    if card_num.isnumeric() and cardcheck(card_num) and len(card_num) == 16:
        await bot.send_message(chat_id=message.chat.id, text = "Записан, введите мм/гг, слитно и без слэша.")
        await state.update_data(card_num=card_num)
        await Card.Card_second_st.set()
    elif message.text == "Отмена":
        await Zakaz.vetv.set()
    else:
        await bot.send_message(chat_id=message.chat.id, text="Ваша карта не валидна, попробуйте ещё раз.")

@dp.message_handler(state = Card.Card_second_st)
async def add_start(message: types.Message,  state: FSMContext):
    card_g = message.text
    if card_g.isnumeric():
        await bot.send_message(chat_id=message.chat.id, text = "Записан, напишите cvc")
        await state.update_data(card_g=card_g)
        await Card.Card_cvc_st.set()
    elif message.text == "Отмена":
        await Zakaz.vetv.set()
    else:
        await bot.send_message(chat_id=message.chat.id, text="Еще раз")

@dp.message_handler(state = Card.Card_cvc_st)
async def add_start(message: types.Message,  state: FSMContext):

    card_cvc = message.text
    if card_cvc.isnumeric():

        await state.update_data(card_cvc=card_cvc)
        data = await state.get_data()
        data_1 = data.get("card_num")

        data_2 = await state.get_data()
        data_3 = data_2.get("card_g")



        await bot.send_message(chat_id=message.chat.id, text = "Готово.")
        await bot.send_message(chat_id=message.chat.id, text=f"Номер карты: {data_1}")
        await bot.send_message(chat_id=message.chat.id, text=f"мм/гг : {data_3}")
        await bot.send_message(chat_id=message.chat.id, text=f"cvc код : {card_cvc}", reply_markup=markup4)
        syqaL = "INSERT INTO Cards values (NULL,'{}', '{}', '{}', '{}')".format(data_1, data_3, card_cvc, data.get('Login_ID'))
        print(syqaL)
        cursor.execute(syqaL)
        con.commit()
        await Zakaz.vetv.set()
    elif message.text == "Отмена":
        await Zakaz.vetv.set()
    else:
        await bot.send_message(chat_id=message.chat.id, text="Еще раз.")



@dp.message_handler(state = "otz_tav")
async def bot_choosing(message: types.Message,state: FSMContext):
    if message.text == "Оставить отзыв":
        await message.answer(text="Пожалуйста, оцените нас по 5-бальной шaкале!", reply_markup=types.ReplyKeyboardRemove())
        await state.set_state("StarRate")
    elif message.text == "Не оставлять отзыв":
        data = await state.get_data()
        if users[data.get('Login_ID') - 1][4] == 1:
            await message.answer(text="Надеемся, вы довольны заказом!", reply_markup=markup6)
        else:
            await message.answer(text="Надеемся, вы довольны заказом!", reply_markup=markup4)
        await Zakaz.vetv.set()

#----


@dp.message_handler(state="StarRate")
async def bot_starrate(message: types.Message,state: FSMContext):
    if message.text.isnumeric():
        if int(message.text) <=5:
            Stars = message.text
            await state.update_data(StarRate = Stars)
            await message.answer(text="Спасибо за вашу оценку! Не хотели бы вы поделиться с нами вашими впечатлениями и оставть отзыв?")
            await state.set_state("ChoosingOptFeedBack")
        else:
            await message.answer(text="Ты че попутал?")
            await state.set_state("StarRate")

@dp.message_handler(state="ChoosingOptFeedBack")
async def bot_choosing(message: types.Message,state: FSMContext):
    data = await state.get_data()
    if message.text == "Да":
        await message.answer(text="Пожалуйста,опишите всё,что вам понравилось как можно подробнее!", reply_markup=types.ReplyKeyboardRemove())
        await state.set_state("FeedBack")
    elif message.text == "Нет":
        rate = data.get('StarRate')
        username = data.get('Username')
        connect = sqlite3.connect("Bufet.db")
        cursor = connect.cursor()
        cursor.execute(f"INSERT INTO FeedBack(Username,Rate) VALUES('{username}',{rate})")
        connect.commit()
        connect.close()
        if users[data.get('Login_ID') - 1][4] == 1:
            await message.answer(text="Возвращайтесь к нам ещё!", reply_markup=markup6)
        else:
            await message.answer(text="Возвращайтесь к нам ещё!", reply_markup=markup4)
        await Zakaz.vetv.set()
    else:
        await message.answer(text="Чета я не понял!")
        await state.set_state("ChoosingOptFeedBack")

@dp.message_handler(state="FeedBack")
async def bot_feedback_check(message: types.Message,state: FSMContext):
    data = await state.get_data()
    FeedBack = message.text
    username = data.get('Username')
    rate = data.get('StarRate')
    connect = sqlite3.connect("Bufet.db")
    cursor = connect.cursor()
    cursor.execute(f"INSERT INTO FeedBack(Username,User_Feedback,Rate) VALUES('{username}','{FeedBack}',{rate})")
    connect.commit()
    connect.close()
    if users[data.get('Login_ID')-1][4] == 1:
        await message.answer(text="Большое спасибо за отзыв, ждем вас снова!", reply_markup=markup6)
    else:
        await message.answer(text="Большое спасибо за отзыв, ждем вас снова!", reply_markup= markup4)
    await Zakaz.vetv.set()
#-----
@dp.message_handler(state=Zakaz.vetv)
async def bot_reset_click(message: types.Message, state: FSMContext):
    data = await state.get_data()
    if message.text == "Сделать заказ":
        await message.answer(text=f"Вот моё меню: ", reply_markup=markup2)
        await Zakaz.shopping.set()
    elif message.text == "Текущие заказы":
        syqaL = f"SELECT * FROM Orders WHERE Username = '{data.get('Login')}' AND Status !=2"
        print(syqaL)
        cursor.execute(syqaL)
        orders = cursor.fetchall()
        print(orders)
        await message.answer(text=f"Вот твои заказы:")
        for i in orders:
            tx = "Заказ: " + i[2]
            if i[3] == 0: tx += "В СБОРКЕ"
            elif i[3] == 1: tx += "У КУРЬЕРА"
            elif i[3] == 2: tx += "ДОСТАВЛЕН"
            elif i[3] == 3: tx += "СОБРАН"
            tx += "\nКОД ПОЛУЧЕНИЯ: " + i[5]
            await message.answer(text=tx)
    if message.text == "Пополнить баланс":
        syqaL = f"SELECT * FROM Cards WHERE User = {data.get('Login_ID')}"
        cursor.execute(syqaL)
        a = cursor.fetchall()
        if len(a) > 0:
            await message.answer(text=f"На какую сумму хотите пополнить баланс?", reply_markup=types.ReplyKeyboardRemove())
            await Card.add_balance.set()
        else:
            await message.answer(text=f"У вас не привязана карта. Привязать?", reply_markup= markup8)
            await Card.add_card.set()
    elif message.text == "Взять заказ":
        if users[data.get('Login_ID')-1][4] == 1:
            syqaL = "SELECT * FROM Orders WHERE Status = 3"
            cursor.execute(syqaL)
            orders = cursor.fetchall()
            tx = "НОМЕР ЗАКАЗА: " + str(orders[0][0]) + "\n КАБИНЕТ ДЛЯ ДОСТАВКИ: " + orders[0][4]
            syqaL = "UPDATE Orders SET Status = 1 WHERE ID = {}".format(orders[0][0])
            cursor.execute(syqaL)
            con.commit()
            await message.answer(text=tx)
        else:
            await message.answer(text="Недостаточно полномочий.")
    elif message.text == "Сдать заказ":
        if users[data.get('Login_ID')-1][4] == 1:
            await message.answer(text="Введите номер заказа, который вы хотите сдать.")
            await Zakaz.zaka.set()
        else:
            await message.answer(text="Недостаточно полномочий.")
    elif message.text == "Оставить отзыв":
        await message.answer(text="Пожалуйста, оцените нас по 5-бальной шaкале!", reply_markup=types.ReplyKeyboardRemove())
        await state.set_state("StarRate")
    elif message.text == "Не оставлять отзыв":
        data = state.get_data()
        if users[data.get('Login_ID') - 1][4] == 1:
            await message.answer(text="Надеемся, вы довольны заказом!", reply_markup=markup6)
        else:
            await message.answer(text="Надеемся, вы довольны заказом!", reply_markup=markup4)
        await Zakaz.vetv.set()
    elif message.text == "Заказы":
        data = await state.get_data()
        Role = data.get('Role')
        answer = message.text
        if (answer != '' or answer != None) and Role == 3:
            cursor.execute("SELECT * FROM Orders WHERE Status <= 1 ")
            results_orders = cursor.fetchall()
            print(results_orders)
            for i in results_orders:
                await message.answer(text=f"Заказ {i[0]} \n:" + f"{i[2]}", reply_markup=markup9)
            await Zakaz.givee.set()
    elif message.text == "Наличие":
        data = await state.get_data()
        Role = data.get('Role')
        answer = message.text
        if (answer != '' or answer != None) and Role == 3:
            cursor.execute("SELECT * FROM Menu ")
            results = cursor.fetchall()
            await state.update_data(results1=results)
            print(results)
            text = ''
            for i in results:
                text = text + str(f"{i[0]} {i[1]} в количестве {i[3]} штук(и)\n" + "\n")
            await message.answer(text="В наличии:")
            await message.answer(text=text)
            key5 = ReplyKeyboardMarkup(
                keyboard=[
                    [
                        KeyboardButton(text="В меню"),
                        KeyboardButton(text="Изменить"),
                    ]
                ],
                resize_keyboard=True
            )
            await message.answer(text="Вернуться или изменить количество", reply_markup=key5)
            await state.set_state('Menu1')

@dp.message_handler(state="Menu1")
async def bot_Menu1(message: types.Message, state: FSMContext):
    data = await state.get_data()
    Role = data.get('Role')
    answer = message.text
    if (answer != '' or answer != None) and Role == 3:
        if answer=="В меню":
            key3 = ReplyKeyboardMarkup(
                keyboard=[
                    [
                        KeyboardButton(text="Заказы"),
                        KeyboardButton(text="Наличие"),
                    ]
                ],
                resize_keyboard=True
            )
            await Zakaz.vetv.set()
            await message.answer(text="Главное меню", reply_markup=key3)
        elif answer=="Изменить":
            results=data.get('results1')

            print(results)
            key6 = ReplyKeyboardMarkup(keyboard=[], resize_keyboard=True)
            for i in results:
                key6.add(KeyboardButton(text=str(f"{i[0]} . {i[1]}")))

            await message.answer(text="Какое поле изменить(число)", reply_markup=key6)
            await state.set_state('Izmen')

@dp.message_handler(state="Izmen")
async def bot_Izmen(message: types.Message, state: FSMContext):
    data = await state.get_data()
    Role = data.get('Role')
    answer = message.text
    if (answer != '' or answer != None) and Role == 3:
        answer=answer[:2]
        def is_int(abc):
            try:
                abc=int(abc)
                return True
            except:
                return False

        if is_int(answer):
            answer=int(answer)
            cursor.execute("SELECT ID FROM Menu")
            results = cursor.fetchall()
            if answer <= len(results):
                ID_vrem=answer
                await state.update_data(ID_vrem=ID_vrem)
                key7 = ReplyKeyboardMarkup(
                    keyboard=[
                        [
                            KeyboardButton(text="Указать"),
                            KeyboardButton(text="Добавить"),
                            KeyboardButton(text="Не изменять")
                        ]
                    ],
                    resize_keyboard=True
                )
                await message.answer(text="Указать значение или добавить количество?", reply_markup=key7)
                await state.set_state('Izmen1')
            else:
                await message.answer(text="Поле не выбрано \n Повторите выбор")

@dp.message_handler(state="Izmen1")
async def bot_Izmen1(message: types.Message, state: FSMContext):
    data = await state.get_data()
    Role = data.get('Role')
    answer = message.text
    if (answer != '' or answer != None) and Role == 3:
        if answer=="Указать":
            await message.answer(text="Какое значение поставить?", reply_markup=types.ReplyKeyboardRemove())
            await state.set_state('Izmen2')

        elif answer=="Добавить":
            await message.answer(text="Сколько добавить?" , reply_markup=types.ReplyKeyboardRemove())
            await state.set_state('Izmen2_1')

        elif answer == "Не изменять":
            cursor.execute("SELECT * FROM Menu ")
            results = cursor.fetchall()
            await state.update_data(results1=results)
            print(results)
            text = ''
            for i in results:
                text = text + str(f"{i[0]} {i[1]} в количестве {i[3]} штук(и)\n" + "\n")
            await message.answer(text="В наличии:")
            await message.answer(text=text)
            key5 = ReplyKeyboardMarkup(
                keyboard=[
                    [
                        KeyboardButton(text="В меню"),
                        KeyboardButton(text="Изменить"),
                    ]
                ],
                resize_keyboard=True
            )
            await message.answer(text="Вернуться или изменить количество", reply_markup=key5)
            await state.set_state('Menu1')

        else:pass


@dp.message_handler(state="Izmen2_1")
async def bot_Izmen2(message: types.Message, state: FSMContext):
    data = await state.get_data()
    Role = data.get('Role')
    answer = message.text
    if (answer != '' or answer != None) and Role == 3:
        def is_int(abc):
            try:
                abc=int(abc)
                return True
            except:
                return False

        if is_int(answer):
            answer=int(answer)
            ID=data.get("ID_vrem")
            cursor.execute(f"UPDATE Menu SET Amount=Amount+'{answer}' WHERE ID='{ID}'")
            con.commit()
            await state.reset_state(with_data=False)
            await message.answer(text="Значение изменено", reply_markup=key3)
            await Zakaz.vetv.set()
        else:
            await message.answer(text="Введите число")

@dp.message_handler(state="Izmen2")
async def bot_Izmen2(message: types.Message, state: FSMContext):
    data = await state.get_data()
    Role = data.get('Role')
    answer = message.text
    if (answer != '' or answer != None) and Role == 3:
        def is_int(abc):
            try:
                abc=int(abc)
                return True
            except:
                return False

        if is_int(answer):
            answer=int(answer)
            ID=data.get("ID_vrem")
            cursor.execute(f"UPDATE Menu SET Amount='{answer}' WHERE ID='{ID}'")
            con.commit()
            await state.reset_state(with_data=False)
            key3 = ReplyKeyboardMarkup(
                keyboard=[
                    [
                        KeyboardButton(text="Заказы"),
                        KeyboardButton(text="Наличие"),
                    ]
                ],
                resize_keyboard=True
            )
            await message.answer(text="значение изменено", reply_markup=key3)
            await state.reset_state(with_data=False)
        else:
            await message.answer(text="Введите число")

@dp.message_handler(state=Zakaz.zaka)
async def answer_q2(message: types.Message, state: FSMContext):
    await state.update_data(zakaz = message.text)
    await message.answer(text="Введите приватный код заказа.")
    await Zakaz.zaka_kod.set()

@dp.message_handler(state=Zakaz.zaka_kod)
async def answer_q2(message: types.Message, state: FSMContext):
    data = await state.get_data()
    syqaL = f"SELECT Private_code FROM Orders WHERE ID = {data.get('zakaz')}"
    cursor.execute(syqaL)
    orders = cursor.fetchall()
    if message.text == orders[0][0]:
        syqaL = f"UPDATE Orders SET Status = 2 WHERE ID = {data.get('zakaz')}"
        cursor.execute(syqaL)
        con.commit()
        await message.answer(text="Заказ сдан")
        syqaL = f"SELECT Adresat FROM Orders WHERE ID = {data.get('zakaz')}"
        print(syqaL)
        cursor.execute(syqaL)
        orders = cursor.fetchall()
        await bot.send_message(orders[0][0], f"Заказ {data.get('zakaz')} доставлен.", reply_markup=markup7)
        a = orders[0][0]
        print(a)
        dfer = dp.current_state(chat=orders[0][0])
        await dfer.reset_state(with_data=False)
        await dfer.set_state('otz_tav')
        A = await dfer.get_state()
        print(A)
        print(dfer)
        print(1)
        print(2)
    else:
        await message.answer(text="Неверный приватный код")
        await message.answer(text="Введите приватный код заказа.")
        await Zakaz.zaka_kod.set()
    print(4)


'''@dp.callback_query_handler(state = "otz_tav")
async def process_callback_minus(callback_query: types.CallbackQuery, state: FSMContext):
    await bot.answer_callback_query(callback_query.id)
    print(3)
    await bot.edit_message_reply_markup(
        chat_id=callback_query.from_user.id,
        message_id=callback_query.message.message_id,
        reply_markup=None
    )
    print(3)
    await bot.send_message(callback_query.from_user.id, "Пожалуйста, оцените нас по 5-бальной шaкале, сэр!")
    await state.set_state("StarRate")'''

@dp.message_handler(state=Zakaz.shopping)
async def answer_q2(message: types.Message, state: FSMContext):
    global menuha
    if message.text[0].isnumeric():
        data = await state.get_data()
        t = ""
        for i in range (0, len(message.text)):
            if message.text[i] != ".":
                t += message.text[i]
            else:
                break
        te = int(t) - 1
        if int(t) <= len(menuha):
            await message.answer(text=f"Мммм, {menuha[te][1]}, отличный выбор! У нас их есть {menuha[te][3]} штук, сколько тебе нужно?", reply_markup=markup2)
            if data.get("food_id") != None:
                print(data.get("food_id"))
                a = data.get("food_id")
                a.append(te)
                await state.update_data(food_id=a)
            else:
                await state.update_data(food_id=[te])
        else:
            await message.answer(text="У нас нет такой позиции!")
        data = await state.get_data()
        print(data.get("food_id"))
        await Zakaz.amount_check.set()
    elif message.text == "Это всё":
        data = await state.get_data()
        if data.get("food_id") != None:
            price = 0
            for i in range(0, len(data.get("food_id"))):
                price += menuha[data.get("food_id")[i]][2] * data.get("food_amount")[i]
            print(price)
            if users[int(data.get("Login_ID")-1)][3] - price >= 0:
                syqaL = "UPDATE Users SET Balance = {} WHERE ID = {}".format(int(users[data.get("Login_ID")-1][3] - price), int(data.get("Login_ID")-1)+1)
                cursor.execute(syqaL)
                con.commit()
                await message.answer(text=f"Заказ сформирован! Укажите адрес, на который необходимо доставить.")
                await Zakaz.adres.set()
            else:
                if users[data.get('Login_ID') - 1][4] == 1:
                    await message.answer(text="Недостаточно средств!", reply_markup=markup6)
                else:
                    await message.answer(text="Недостаточно средств!", reply_markup=markup4)
                await Zakaz.vetv.set()
        else:
            if users[data.get('Login_ID') - 1][4] == 1:
                await message.answer(text="Сегодня без еды :(", reply_markup=markup6)
            else:
                await message.answer(text="Сегодня без еды :(", reply_markup=markup4)
            await Zakaz.vetv.set()

@dp.message_handler(state=Zakaz.amount_check)
async def answer_q2(message: types.Message, state: FSMContext):
    global menuha
    data = await state.get_data()
    print(1)
    print(data.get("food_id"))
    if message.text.isnumeric():
        if int(message.text) > menuha[len(data.get("food_id"))][3]:
            await message.answer("Это слишком много, у нас столько нет. Возьми поменьше, пожалуйста.")
            await Zakaz.amount_check.set()
        else:
            if data.get("food_amount") != None:
                a = data.get("food_amount")
                a.append(int(message.text))
                await state.update_data(food_amount=a)
            else:
                await state.update_data(food_amount=[int(message.text)])
            data = await state.get_data()
            text = ""
            for i in range (0, len(data.get("food_id"))):
                text += menuha[data.get("food_id")[i]][1] + " в количестве " + str(data.get("food_amount")[i]) + " штук" + '\n'
            await message.answer(text="Отлично! Вот твой заказ: \n"+text+"Когда закончишь, выбери пункт ''Это всё''.")
            await state.update_data(order = text)
            await Zakaz.shopping.set()
    else:
        await message.answer("Введи числовое значение.")

@dp.message_handler(state=Zakaz.otv)
async def answer_q2(message: types.Message, state: FSMContext):
    if message.text == "Это всё":
        data = await state.get_data()
        price = 0
        for i in range(0, len(data.get("food_id"))):
            price += menuha[data.get("food_id")[i]][2] * data.get("food_amount")[i]
        print(price)
        if users[int(data.get("Login_ID")-1)][3] - price >= 0:
            syqaL = "UPDATE Users SET Balance = {} WHERE ID = {}".format(int(users[data.get("Login_ID")-1][3] - price), int(data.get("Login_ID")-1)+1)
            cursor.execute(syqaL)
            con.commit()
            await message.answer(text=f"Заказ сформирован! Укажите кабинет, в который необходимо доставить.")
            await Zakaz.adres.set()
        else:
            await message.answer(text=f"Недостаточно средств!")
    elif message.text == "Выбрать ещё позиции":
        await message.answer(text=f"Вот моё меню: ", reply_markup=markup2)
        await Zakaz.shopping.set()

@dp.message_handler(state=Zakaz.adres)
async def answer_q2(message: types.Message, state: FSMContext):
    if message.text.isnumeric and len(message.text)<5:
        data = await state.get_data()
        a = ""
        for i in range (4): a += str(random.randint(0, 9))
        syqaL = "INSERT INTO Orders values (NULL,'{}', '{}', 0, '{}', '{}', '{}')".format(users[data.get("Login_ID")-1][1], data.get("order"), message.text, a, message.from_user.id)
        print(syqaL)
        cursor.execute(syqaL)
        con.commit()
        await message.answer(text=f"Отлично! Ожидайте доставки.", reply_markup=markup4)
        for i in range (0, len(data.get("food_id"))):
            syqaL = "UPDATE Menu SET Amount = {} WHERE ID = {}".format(menuha[data.get("food_id")[i]][3] - data.get("food_amount")[i], data.get("food_id")[i])
            print(syqaL)
            cursor.execute(syqaL)
            con.commit()
        await state.update_data(food_id = None)
        await state.update_data(food_amount=None)
        await state.update_data(order=None)
        await Zakaz.vetv.set()
    else:
        await message.answer("Введи номер кабинета.")

@dp.message_handler(state=Zakaz.givee)
async def answer_q2(message: types.Message, state: FSMContext):
    if message.text == "Сдать заказ":
        await message.answer(text="Напиши номер заказа, который хочешь сдать.")
        await Zakaz.sgive.set()
    elif message.text == "В меню":
        await message.answer(text="Выбери опцию:", reply_markup=key3)
        await Zakaz.vetv.set()

@dp.message_handler(state=Zakaz.sgive)
async def answer_q2(message: types.Message, state: FSMContext):
    if message.text.isnumeric():
        cursor.execute("SELECT ID FROM Orders WHERE Status = 0 ")
        rer = cursor.fetchall()
        print(message.text+"----------------------")
        for i in rer:
            if i[0] == int(message.text):
                print(i[0])
                await message.answer(text="Заказ сдан!", reply_markup=markup9)
                syqaL = f"UPDATE Orders SET Status = 3 WHERE ID = {int(message.text)}"
                cursor.execute(syqaL)
                con.commit()
                await Zakaz.givee.set()


executor.start_polling(dp)