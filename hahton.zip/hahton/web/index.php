<html lang="en" dir="ltr">

<head>
  <meta charset="utf-8">
  <title>BulochBot</title>

  <link rel="stylesheet" href="style.css">

  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Lunasima&family=Voces&display=swap" rel="stylesheet">

  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Andika&display=swap" rel="stylesheet">

</head>

<body>
  <div class="TopBox">
    <div class="Top">
      <div class="Top_Main">
        <div class="Top_Main_S">
          <div class="lgo">
            <img src="Logo.png" alt="yasher">
          </div>
        </div>
        <div class="Top_Main_S">
          <a href="index.html" class="bot">БулочБот</a>
        </div>
        <div class="Top_Main_S">
          <a href="#" class="msg">Написать боту</a>
        </div>
      </div>
      <div class="Top_Nav">

        <a href="menu.php">Меню</a>
        <a href="index.php">Главная</a>
        <a href="reviews.php">Отзывы</a>

      </div>
    </div>
  </div>
  <div class="Main">
    <div class="Sign">
      <h1>Главная Страница:</h1>
    </div>
    <div class="Main_Info">
      <div class="Main_Info_Block">
        <div class="Main_Info_Block_Txt">
          <div class="Main_Info_Block_Txt_Title">
            <p>Добро пожаловать на сайт БулочБота! <br> С БулочБотом вы сможете получить еду из вашего школьного буфета, не напрягаясь.</p>
          </div>
          <p>Многие часто сталкивались с проблемой гото, что очереди к школьному буфету огромные, а перемена не бусконечная, из-за чего вы можете прождать всю перемену, не получив возможности купить еды из буфета. Это просто ужасно. БулочБот был создан именно для того, чтобы побороть эту проблему. Вам сего лишь нужно написать Телегрм-Боту "БулочБот" и ваша еда окажется у вас без выхода из класса и стояния в очереди, благодаря нашим курьерам.</p>
        </div>
        <div class="Main_Info_Block_Img">
        </div>
      </div>
    </div>
  </div>
</body>

</html>
