<html lang="en" dir="ltr">

<head>
  <meta charset="utf-8">
  <title>BulochBot</title>

  <link rel="stylesheet" href="style.css">

  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Lunasima&family=Voces&display=swap" rel="stylesheet">

  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Andika&display=swap" rel="stylesheet">


</head>

<body>
  <div class="TopBox">
    <div class="Top">
      <div class="Top_Main">
        <div class="Top_Main_S">
          <div class="lgo">
            <img src="Logo.png" alt="yasher">
          </div>
        </div>
        <div class="Top_Main_S">
          <a href="index.php" class="bot">БулочБот</a>
        </div>
        <div class="Top_Main_S">
          <a href="#" class="msg">Написать боту!</a>
        </div>
      </div>
      <div class="Top_Nav">

        <a href="menu.php">Меню</a>
        <a href="index.php">Главная</a>
        <a href="reviews.php">Отзывы</a>

      </div>
    </div>
  </div>
  <div class="Main">
    <div class="Sign">
      <h1>Меню Буфета:</h1>
    </div>
    <div class="Menu_List">
    <?php

      $pdo = new PDO('sqlite:Bufet.db');

      $statement = $pdo->query('SELECT * FROM Menu');
      $menuelmnts = $statement->fetchAll(PDO::FETCH_ASSOC);

      $statement = $pdo->query('SELECT COUNT(*) FROM Menu');
      $menuelmntcnt = $statement->fetchColumn();

      // print_r($menuelmntcnt);

      foreach($menuelmnts as $row => $elmnt){

          echo'<div class="Menu_list_Elmnt">';
            echo'<div class="Menu_List_E_Img" id="img'.$elmnt["ID"].'">';
            echo'</div>';
            echo'<div class="Menu_List_E_Name">';
              echo'<p>' . $elmnt["Name"] . '<p>';
            echo'</div>';
            echo'<div class="Menu_List_E_Prices">';
              echo'<p>Цена: '.$elmnt["Price"]. ' руб.</p>';
          echo'</div>';
        echo'</div>';

      }

    ?>
    </div>
  </div>
</body>
</html>
