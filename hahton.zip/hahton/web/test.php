<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
    <style media="screen">
    .Menu_List {

      /* border: 2px solid black; */
      display: flex;
      flex-direction: row;
      flex-wrap: wrap;

    }

    .Menu_list_Elmnt {

      /* border: 2px solid yellow; */
      width: 300px;
      height: 440px;
      margin: 20px;

    }

    .Menu_List_E_Img {

      width: 296px;
      height: 246px;
      background-image: url("Steake.jpg");
      background-repeat: no-repeat;
      background-size: cover;
      background-position: bottom;
      /* border: 2px solid red; */
      border: 2px solid #2f2f09;
      border-top-right-radius: 20px;
      border-top-left-radius: 20px;

    }

    .Menu_List_E_Name {

      height: 90px;
      background-color: #2f2f09;
      /* border: 2px solid green; */
      border-bottom-right-radius: 20px;

    }

    .Menu_List_E_Name p {

      margin: 2px;
      color: #c5b9a3;
      font-size: 15px;
      margin-top: 2px;
      margin-left: 10px;
      line-height: 15px;

    }

    .Menu_List_E_Name h1{

      margin: 0px;
      margin-left: 20px;
      line-height: 25px;
      font-size: 22px;
      background: linear-gradient(135deg, #c5b9a3 0%, #b81200 25%, #b81200 100%);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;

    }

    .Menu_List_E_Prices {

      /* display: flex;
      flex-direction: row-reverse; */
      height: 30px;
      background-color: #d0e949;
      /* border: 2px solid blue; */
      margin: 10px;
      margin-top: 0px;
      margin-right: 150px;
      border-bottom-left-radius: 10px;

    }

    .Menu_List_E_Prices p {

      margin: 0px;
      margin-left: 20px;

    }
    </style>
  </head>
  <body>

    <h1>Header</h1>

    <?php

      echo"<p>Aaa</p>";

      $pdo = new PDO('sqlite:Bufet.db');

      $statement = $pdo->query('SELECT * FROM Menu');
      $menuelmnts = $statement->fetchAll(PDO::FETCH_ASSOC);

      $statement = $pdo->query('SELECT COUNT(*) FROM Menu');
      $menuelmntcnt = $statement->fetchColumn();

      print_r($menuelmntcnt);

      foreach($menuelmnts as $row => $elmnt){

        echo'<div class="Menu_List">';
          echo'<div class="Menu_list_Elmnt">';
            echo'<div class="Menu_List_E_Img">';
            echo'</div>';
            echo'<div class="Menu_List_E_Name">';
              echo'<h1>' . $elmnt["Name"] . '</h1>';
              echo'<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit.</p>';
            echo'</div>';
            echo'<div class="Menu_List_E_Prices">';
              echo'<p>Price:'.$elmnt["Price"].'</p>';
          echo'</div>';
        echo'</div>';

      }
      echo "</table>";

    ?>
  </body>
</html>
