<html lang="en" dir="ltr">

<head>
  <meta charset="utf-8">
  <title>BulochBot</title>

  <link rel="stylesheet" href="style.css">

  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Lunasima&family=Voces&display=swap" rel="stylesheet">

  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Andika&display=swap" rel="stylesheet">

</head>

<body>
  <div class="TopBox">
    <div class="Top">
      <div class="Top_Main">
        <div class="Top_Main_S">
          <div class="lgo">
            <img src="Logo.png" alt="yasher">
          </div>
        </div>
        <div class="Top_Main_S">
          <a href="index.html" class="bot">БулочБот</a>
        </div>
        <div class="Top_Main_S">
          <a href="#" class="msg">Написать боту</a>
        </div>
      </div>
      <div class="Top_Nav">

        <a href="menu.php">Меню</a>
        <a href="index.php">Главная</a>
        <a href="reviews.php">Отзывы</a>

      </div>
    </div>
  </div>
  <div class="Main">
    <div class="Sign">
      <h1>Отзывы Пользователей:</h1>
    </div>
    <div class="Review_List">
      <?php

        $pdo = new PDO('sqlite:Bufet.db');

        $statement = $pdo->query('SELECT * FROM FeedBack');
        $reviewelmnts = $statement->fetchAll(PDO::FETCH_ASSOC);

        $statement = $pdo->query('SELECT COUNT(*) FROM FeedBack ');
        $reviewelmntcnt = $statement->fetchColumn();

        // print_r($menuelmntcnt);

        foreach($reviewelmnts as $row => $elmnt){
          echo'<div class="Review_List">';
          echo'<div class="Review_List_Elmnt">';
            echo'<div class="Review_List_E_Top">';
              echo'<div class="Review_List_E_Name">';
                echo'<p>Имя: '.$elmnt["Username"].'</p>';
              echo'</div>';
              echo'<div class="Review_List_E_Rate">';
                echo'<p>'  .  $elmnt["Rate"]  .  '</p>';
              echo'</div>';
            echo'</div>';
            echo'<div class="Review_List_E_Content">';
              echo'<h1>Отзыв:</h1>';
              echo'<p>'  .  $elmnt["User_Feedback"]  .  '</p>';
            echo'</div>';
            echo'</div>';
          echo'</div>';
        }

      ?>
    </div>
  </div>
</body>

</html>
